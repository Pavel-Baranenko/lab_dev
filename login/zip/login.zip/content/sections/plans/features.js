
const styles_d = {
  "buttons": {
    "yellowBtn": {
      "default": {
        "borderRadius": "13px",
        "paddingTop": "clamp(2svh, 10svh, 11px)",
        "paddingBottom": "clamp(2svh, 10svh, 11px)",
        "paddingLeft": "clamp(5svw, 2vw, 50px)",
        "paddingRight": "clamp(5svw, 2vw, 50px)",
        "width": "fit-content",
        "height": "clamp(16svh, 10svh, 50px)",
        "background": "#fed05e",
        "fontWeight": "500",
        "fontSize": "clamp(14px, 2vw, 20px)",
        "textAlign": "center",
        "marginTop": "clamp(1svh, 10svh, 40px)",
        "border": "none"
      },
      "Landscape": {
        "paddingLeft": "50px",
        "paddingRight": "50px"
      }
    },
    "action": {
      "default": {
        "borderRadius": "15px",
        "paddingBottom": "clamp(2svh, 5svh, 12px)",
        "paddingTop": "clamp(2svh, 5svh, 12px)",
        "paddingLeft": "clamp(2svw, 5svw, 20px)",
        "paddingRight": "clamp(2svw, 5svw, 20px)",
        "background": "#feda31",
        "fontWeight": "700",
        "font-size": "clamp(10px, 14px, 18px)",
        "color": "#000",
        "border": "none",
        "boxSizing": "border-box",
        "textAlign": "center"
      }
    },
    "grey": {
      "default": {
        "borderRadius": "15px",
        "paddingBottom": "clamp(2svh, 5svh, 12px)",
        "paddingTop": "clamp(2svh, 5svh, 12px)",
        "paddingLeft": "clamp(2svw, 5svw, 20px)",
        "paddingRight": "clamp(2svw, 5svw, 20px)",
        "background": "#DFDFDF",
        "fontWeight": "700",
        "font-size": "clamp(10px, 14px, 18px)",
        "color": "#000",
        "border": "none",
        "boxSizing": "border-box"
      }
    }
  },
  "inputs": {
    "standart": {
      "default": {
        "borderRadius": "18px",
        "padding": "0 15px",
        "outline": "none !important",
        "width": "75%",
        "maxWidth": "350px",
        "height": "clamp(5svh, 15vh, 70px)",
        "background": "#f4f4f5",
        "backgroundColor": "white",
        "marginBottom": "clamp(1svh, 15vw, 20px)",
        "border": "none"
      }
    }
  },
  "pages": {
    "login": {
      "default": {
        "position": "absolute",
        "top": 0,
        "left": 0,
        "width": "100svw",
        "height": "100svh",
        "background": "#EFEFEF",
        "display": "flex",
        "flexDirection": "column",
        "alignItems": "center",
        "fontFamily": "Petrona"
      },
      "Portrait": {
        "justifyContent": "center"
      }
    },
    "dash": {
      "default": {
        "background": "rgb(239, 239, 239)",
        "display": "flex",
        "flexDirection": "column",
        "minHeight": "100vh",
        "overflowY": "auto"
      }
    }
  },
  "labels": {
    "h6": {
      "default": {
        "width": "90%",
        "color": "#808080",
        "fontWeight": "700",
        "fontSize": "clamp(20px, 2vw, 40px)",
        "marginBottom": "clamp(5px, 10svh, 44px)",
        "textAlign": "center"
      }
    }
  },
  "links": {
    "underline": {
      "default": {
        "fontWeight": "300",
        "fontSize": "clamp(12px, 2vw, 20px)",
        "textDecoration": "underline",
        "textAlign": "center",
        "color": "#808080"
      }
    },
    "legal": {
      "default": {
        "fontWeight": "400",
        "fontSize": "14px",
        "textDecoration": "underline",
        "textAlign": "left",
        "color": "#fff"
      }
    },
    "contact": {
      "default": {
        "fontWeight": "700",
        "fontSize": "14px",
        "textDecoration": "underline",
        "textAlign": "left",
        "color": "#fff",
        "marginLeft": "auto"
      }
    }
  },
  "logo": {
    "medium": {
      "default": {
        "marginTop": "clamp(10px, 2vw, 60px)",
        "marginBottom": "clamp(10px, 2vw, 60px)",
        "width": "clamp(50px, 15svh, 101px)"
      }
    },
    "small": {
      "default": {
        "width": "clamp(40px, 2svw,67px)",
        "height": "clamp(45px, 2svw,75px)"
      }
    }
  },
  "search": {
    "box": {
      "default": {
        "background": "#fff",
        "height": "clamp( 35px,5svh,50px)",
        "boxSizing": "border-box",
        "borderRadius": "40px",
        "cursor": "pointer",
        "display": "flex",
        "alignItems": "center",
        "position": "relative",
        "padding": "0 15px"
      },
      "Portrait": {
        "order": "98",
        "width": "calc(100% - 85px)"
      },
      "Landscape": {
        "width": "clamp(20svw, 50svw, 500px)",
        "margin": "0 auto"
      }
    },
    "input": {
      "default": {
        "width": "100%",
        "padding": "0 10px 0 5px",
        "border": "none",
        "outline": "none"
      }
    },
    "result": {
      "default": {
        "zIndex": "-1",
        "position": "absolute",
        "top": "calc(100% - 20px)",
        "width": "100%",
        "left": "0",
        "borderRadius": "0 0 15px 15px",
        "overFlow": "hidden",
        "fontSize": "14px",
        "background": "#fff"
      }
    },
    "item": {
      "default": {
        "padding": "5px 50px",
        "display": "block",
        "textDecoration": "none",
        "color": "#000"
      }
    },
    "first": {
      "default": {
        "padding": "20px 50px 5px 50px",
        "display": "block",
        "textDecoration": "none",
        "color": "#000"
      }
    }
  },
  "containers": {
    "header": {
      "default": {
        "display": "flex",
        "boxSizing": "border-box",
        "alignItems": "center",
        "paddingTop": "clamp(2svh, 12svh, 30px)",
        "paddingBottom": "clamp(0, 0, 30px)",
        "paddingLeft": "clamp(2svw, 5svw, 60px)",
        "paddingRight": "clamp(2svw, 5svw, 60px)",
        "position": "relative",
        "zIndex": "9999",
        "width": "100%"
      },
      "Portrait": {
        "justifyContent": "space-between",
        "flexWrap": "wrap",
        "gap": "8px"
      }
    },
    "footer": {
      "default": {
        "display": "flex",
        "alignItems": "center",
        "color": "#fff",
        "boxSizing": "border-box",
        "marginTop": "auto",
        "flexWrap": "wrap",
        "background": "#464C59",
        "paddingTop": "clamp(2svh, 12svh, 30px)",
        "paddingBottom": "clamp(2svh, 12svh, 30px)",
        "paddingLeft": "clamp(2svw, 5svw, 60px)",
        "paddingRight": "clamp(2svw, 12svw, 60px)"
      }
    }
  },
  "elements": {
    "avatar": {
      "default": {
        "borderRadius": "50px",
        "backgroundColor": "#ddd",
        "position": "relative",
        "width": "clamp(45px,5svw,50px)",
        "aspectRatio": 1,
        "border": "none"
      },
      "Landscape": {
        "marginLeft": "50px"
      }
    },
    "date": {
      "default": {
        "fontSize": "14px",
        "fontWeight": "400",
        "lineHeight": "19.1px",
        "textAlign": "left"
      },
      "Landscape": {
        "marginRight": "45px"
      }
    },
    "theme": {
      "default": {
        "border": "2px solid #585858",
        "cursor": "pointer",
        "width": "40px",
        "height": "20px",
        "boxSizing": "border-box",
        "display": "flex",
        "alignItems": "center",
        "borderRadius": "10px",
        "padding": "0 2px",
        "marginLeft": "20px"
      }
    },
    "colorTheme": {
      "default": {
        "background": "rgb(252, 206, 92)",
        "width": "10px",
        "height": "10px",
        "boxSizing": "border-box",
        "display": "flex",
        "borderRadius": "10px",
        "alignItems": "center",
        "justifyContent": "start"
      }
    },
    "gridSwitch": {
      "default": {
        "background": "#E2E2E2",
        "boxSizing": "border-box",
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between"
      },
      "Landscape": {
        "padding": "5px",
        "borderRadius": "50px",
        "marginRight": "5svw",
        "width": "110px",
        "height": "50px"
      },
      "Portrait": {
        "padding": "3.5px",
        "width": "77px",
        "height": "35px",
        "borderRadius": "35px",
        "order": "99"
      }
    },
    "gridBtn": {
      "default": {
        "border": "none",
        "background": "transparent",
        "boxSizing": "border-box",
        "borderRadius": "50%",
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "center"
      },
      "Landscape": {
        "width": "40px",
        "height": "40px",
        "padding": "5px"
      },
      "Portrait": {
        "width": "28px",
        "height": "28px",
        "padding": "6px"
      }
    }
  },
  "header": {
    "menu": {
      "default": {
        "display": "flex",
        "flexDirection": "column",
        "zIndex": "25",
        "gap": "30px",
        "fontSize": "18px",
        "fontWeight": "600",
        "lineHeight": "24.55px",
        "textAlign": "left",
        "position": "absolute",
        "top": "calc(100% + 9px)",
        "right": "0",
        "boxShadow": "0px 1px 13.9px 0px #00000014",
        "padding": "32px 25px",
        "borderRadius": "15px",
        "backgroundColor": "#fff",
        "opacity": "0"
      }
    },
    "link": {
      "default": {
        "display": "flex",
        "alignItems": "center",
        "flexDirection": "row-reverse",
        "gap": "12px",
        "justifyContent": "flex-end",
        "color": "#000",
        "textDecoration": "none",
        "border": "none"
      }
    }
  },
  "apps": {
    "list": {
      "default": {
        "position": "relative",
        "display": "flex",
        "flexWrap": "wrap",
        "gap": "20px 0",
        "boxSizing": "border-box",
        "justifyContent": "space-between",
        "paddingTop": "clamp(2svh, 30px, 50px)",
        "paddingBottom": "clamp(2svh, 12svh, 50px)",
        "paddingLeft": "clamp(2svw, 5svw, 60px)",
        "paddingRight": "clamp(2svw, 5svw, 60px)"
      }
    },
    "row": {
      "default": {
        "flex": "0 1 24%",
        "boxshadow": "2px 4px 30px 1px rgba(0, 0, 0, 0.09)",
        "background": "#fff",
        "borderRadius": "20px",
        "aspectRatio": 1.39,
        "display": "flex",
        "flexDirection": "column",
        "cursor": "pointer",
        "position": "relative",
        "boxSizing": "border-box",
        "zIndex": "0"
      },
      "Portrait": {
        "flex": "0 1 100%"
      }
    },
    "column": {
      "default": {
        "flex": "0 1 100%",
        "background": "#fff",
        "display": "flex",
        "justifyContent": "space-between",
        "cursor": "pointer",
        "position": "relative",
        "boxSizing": "border-box",
        "zIndex": "0",
        "borderRadius": "10px"
      }
    },
    "preview": {
      "default": {
        "height": "calc(100% - 40px)",
        "backgroundColor": "#fff",
        "borderRadius": "20px 20px 0 0",
        "backgroundRepeat": "no-repeat",
        "backgroundPosition": "center",
        "backgroundSize": "26%",
        "backgroundImage": "url(`https://laboranth.tech/D/R/IMG/logoAlt.svg`)"
      }
    },
    "wrap-row": {
      "default": {
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between",
        "height": "40px",
        "backgroundColor": "#fff",
        "padding": "10px 10px 10px 30px",
        "fontWeight": "400",
        "fontSize": "16px",
        "color": "#000",
        "borderRadius": "0 0 20px 20px"
      }
    },
    "wrap-column": {
      "default": {
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between",
        "height": "40px",
        "width": "100%",
        "padding": "10px 10px 10px 30px",
        "fontWeight": "400",
        "fontSize": "16px",
        "color": "#000"
      }
    },
    "box": {
      "default": {
        "display": "flex",
        "flexDirection": "column",
        "gap": "20px",
        "paddingRight": "12px"
      }
    },
    "menu": {
      "default": {
        "position": "absolute",
        "top": "calc(100% - 40px)",
        "backgroundColor": "#fff",
        "boxShadow": "0px 1px 13.9px 0px #00000014",
        "right": 0,
        "display": "flex",
        "opacity": 0,
        "flexDirection": "column",
        "padding": "11px 11px 27px 27px",
        "borderRadius": "15px",
        "gap": "10px",
        "zIndex": "26"
      }
    },
    "settings": {
      "default": {
        "background": "transparent",
        "display": "flex",
        "flexDirection": "row-reverse",
        "justifyContent": "flex-end",
        "alignItems": "center",
        "gap": "12px",
        "textTransform": "capitalize",
        "border": "none"
      }
    },
    "more": {
      "default": {
        "transform": "rotate(90deg)",
        "width": "25px",
        "marginLeft": "auto"
      }
    }
  },
  "parameters": {
    "popup": {
      "default": {
        "display": "flex",
        "opacity": "1",
        "backgroundColor": "#FFFFFF",
        "borderRadius": "40px",
        "overflow": "hidden",
        "maxWidth": "1080px",
        "width": "100%",
        "minHeight": "clamp(90%, 50%, 600px)",
        "transform": "translateY(-50%) translateX(-50%)",
        "position": "fixed",
        "zIndex": "9999",
        "left": "50%",
        "top": "50%",
        "transition": "all 0.7s linear"
      }
    },
    "wrapper": {
      "default": {
        "position": "fixed",
        "zIndex": "9999",
        "left": "0",
        "right": "0",
        "top": "0",
        "bottom": "0"
      }
    },
    "side": {
      "default": {
        "backgroundColor": "#3C4CA6",
        "color": "#fff",
        "padding": "24px 0 24px 24px",
        "minHeight": "100%",
        "display": "flex",
        "flexDirection": "column",
        "position": "relative"
      }
    },
    "box": {
      "default": {
        "boxSizing": "border-box",
        "paddingTop": "clamp(5px, 35px, 60px)",
        "paddingBottom": "clamp(5px, 35px, 60px)",
        "paddingRight": "clamp(5px, 35px, 120px)",
        "paddingLeft": "clamp(5px, 35px, 60px)",
        "width": "100%",
        "display": "flex",
        "flexDirection": "column",
        "gap": "clamp(2svw, 5svw, 32px)"
      },
      "Portrait": {
        "padding": "clamp(1svw, 3svw, 25px)"
      }
    },
    "btn": {
      "default": {
        "display": "flex",
        "width": "100%",
        "color": "#fff",
        "background-color": "transparent",
        "border": "none",
        "padding": "10px",
        "paddingRight": "3svw",
        "borderRadius": "10px 0 0 10px",
        "gap": "15px",
        "flexDirection": "row-reverse",
        "justifyContent": "flex-end",
        "fontSize": "18px",
        "height": "45px",
        "fontWeight": "600",
        "lineHeight": "24.55px",
        "textAlign": "left",
        "zIndex": "1",
        "position": "relative"
      }
    },
    "white": {
      "default": {
        "width": "100%",
        "background-color": "#fff",
        "borderRadius": "10px 0 0 10px",
        "height": "45px",
        "position": "absolute",
        "top": 0,
        "right": 0,
        "zIndex": "1",
        "transition": "all 0.1s ease"
      }
    },
    "line": {
      "default": {
        "display": "flex",
        "justifyContent": "space-between",
        "fontSize": "18px",
        "fontWeight": "500",
        "textAlign": "left"
      }
    },
    "confirm": {
      "default": {
        "display": "flex",
        "flexDirection": "column",
        "gap": "10px"
      }
    },
    "buttons": {
      "default": {
        "display": "flex",
        "gap": "26px"
      }
    }
  },
  "select": {
    "box": {
      "default": {
        "cursor": "pointer",
        "width": "clamp(120px, 15svw, 160px)",
        "position": "relative"
      }
    },
    "top": {
      "default": {
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between",
        "width": "100%",
        "boxSizing": "border-box",
        "height": "40px",
        "fontSize": "16px",
        "fontWeight": "500",
        "textAlign": "center",
        "padding": "10px 0 10px 20px",
        "backgroundColor": "#F4F4F5",
        "borderRadius": "10px"
      }
    },
    "list": {
      "default": {
        "display": "none",
        "position": "absolute",
        "top": "calc(100% - 10px)",
        "flexDirection": "column",
        "gap": "4px",
        "boxSizing": "border-box",
        "backgroundColor": "#F4F4F5",
        "padding": "10px",
        "borderRadius": "0 0 10px 10px",
        "width": "100%"
      }
    }
  },
  "input": {
    "box": {
      "default": {
        "outline": "none",
        "width": "clamp(120px, 15svw,200px)",
        "height": "40px",
        "textAlign": "center",
        "backgroundColor": "#F4F4F5",
        "borderRadius": "10px",
        "border": "none"
      }
    }
  },
  "popup": {
    "box": {
      "default": {
        "position": "fixed",
        "top": "20%",
        "cursor": "pointer",
        "width": "clamp(120px, 80svw, 1100px)",
        "background": "#E4E4E4",
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "center",
        "zIndex": "99",
        "left": "50%",
        "transform": "translateX(-50%)",
        "paddingTop": "clamp(2svh, 5svh, 40px)",
        "paddingBottom": "clamp(2svh, 5svh, 40px)",
        "borderRadius": "30px"
      }
    },
    "wrap": {
      "default": {
        "position": "fixed",
        "top": "0",
        "right": 0,
        "left": 0,
        "bottom": 0,
        "zIndex": "99"
      }
    },
    "content": {
      "default": {
        "width": "clamp(60%, 60%, 80%)",
        "display": "flex",
        "flexDirection": "column",
        "alignItems": "center",
        "justifyContent": "center",
        "height": "90%",
        "gap": "25px"
      }
    },
    "title": {
      "default": {
        "fontSize": "32px",
        "fontWeight": "700",
        "lineHeight": "38.58px",
        "textClign": "center",
        "color": "#000",
        "marginBottom": "15px"
      }
    },
    "input": {
      "default": {
        "outline": "none",
        "height": "40px",
        "textAlign": "center",
        "backgroundColor": "#fff",
        "borderRadius": "10px",
        "border": "none"
      }
    }
  },
  "alert": {
    "wrap": {
      "default": {
        "max-width": "250px",
        "position": "fixed",
        "top": "120px",
        "right": "0",
        "background": "#6F6E6E",
        "padding": "10px 16px",
        "borderRadius": "10px 0px 0px 10px",
        "zIndex": "9999",
        "color": "#fff",
        "opacity": "0",
        "transition": "all 0.3s linear",
        "transform": "translateX(100%)"
      }
    }
  },
  'plans': {
    'wrap': {
      'default': {
        'display': "flex",
        "boxSizing": "border-box",
        "justifyContent": "space-between",
        "paddingTop": "clamp(2svh, 30px, 50px)",
        "paddingBottom": "clamp(2svh, 12svh, 50px)",
        "paddingLeft": "clamp(2svw, 5svw, 60px)",
        "paddingRight": "clamp(2svw, 5svw, 60px)",
        'gap': "clamp(10px,2vw,50px)"
      },
      "Portrait": {
        'flexDirection': "column"
      }
    },
    'plan': {
      'default': {
        display: 'flex',
        'position': "relative",
        'height': "fit-content",
        flexDirection: 'column',
        'padding': "34px 20px",
        borderRadius: '45px',
        background: "#fff",
        boxShadow: '0 6px 33px 0 rgba(0, 0, 0, 0.11)'
      },
      "Landscape": {
        'flex': "0 1 21%",
      }
    },
    'angle': {
      'default': {
        'position': "absolute",
        top: 0,
        right: 0
      }
    },
    'title': {
      'default': {
        fontSize: '24px',
        marginLeft: "12px",
        fontWeight: 700,
        marginBottom: "15px",

      }
    },
    'description': {
      'default': {
        fontSize: '14px',
        fontStyle: 'italic',
        marginLeft: "12px",
        fontWeight: 600,
        marginBottom: "20px",

      }
    },
    'box': {
      'default': {
        'display': "flex",
        'alignItems': 'end',
        marginLeft: "12px",
        fontSize: '15px',
        marginBottom: "20px",
        gap: "4px"

      }
    },
    'price': {
      'default': {
        fontSize: '40px',
        fontWeight: 800,
      }
    },
    'point': {
      'default': {
        'display': "flex",
        'alignItems': 'flex-start',
        gap: "7px",
        'lineHeight': "1",
        fontSize: '14px',
        color: '#000'
      }
    },
    'points': {
      'default': {
        'display': "flex",
        flexDirection: "column",
        gap: "20px",
        padding: "20px",
        borderRadius: '25px',
        marginBottom: "20px",
        background: '#f0f0f0'
      }
    },
    'heading': {
      'default': {
        fontWeight: 700,
        fontSize: '40px',
        marginBottom: "20px",
        marginLeft: '12px',
        color: '#000',
      }
    },
    'bold': {
      'default': {
        fontWeight: 700,
      }
    },
    'btn': {
      'default': {
        fontWeight: 700,
        fontSize: '18px',
        textAlign: 'center',
        color: '#fff',
        padding: '12px 35px',
        borderRadius: '15px',
        margin: "0 auto",
        border: 'none',
        cursor: "pointer"
      }
    },
  }
}



function lab_design_system_d(tag, id, parent, content, className, styled) {
  const elementToAppend = document.createElement(tag)
  const styles = styles_d

  elementToAppend.setAttribute("id", "lab-" + id)
  parent.appendChild(elementToAppend)

  const A = document.querySelector("#" + "lab-" + id)
  A.setAttribute("class", "escape")
  className ? elementToAppend.setAttribute("class", `lab-${className} escape`) : ""

  if (content && typeof content == "string") {
    A.innerText = content
  }
  A.style.opacity = 1
  if (styled) {
    let elementStyles = styled.length > 1 ? styles[styled[0]][styled[1]] : styles[styled[0]]

    Object.keys(elementStyles.default).forEach(e => {
      A.style[e] = elementStyles.default[e]
    })

    if (elementStyles[lab_orientation]) {
      Object.keys(elementStyles[lab_orientation]).forEach(e => {
        A.style[e] = elementStyles[lab_orientation][e]
      })
    }
  }

  return A
}

function footer(parent) {
  rootLayer.setAttribute('class', 'lab-laboranth-scroll-classic')
  const footer = lab_design_system_d("div", "footer", parent, null, null, ['containers', 'footer'])
  const text = lab_design_system_d("span", "date", footer, `Laboranth>  |  ${new Date().getFullYear()}`, null, ['elements', 'date'])

  const link = lab_design_system_d("a", "legal", footer, "Legal CGU/CGV", null, ['links', 'legal'])
  link.setAttribute("href", "https://laboranth.tech/D/R/PDF/LegalLaboranthSAS.pdf")

  const contact = lab_design_system_d("a", "contacts", footer, "contact@laboranth.tech", null, ['links', 'contact'])
  contact.setAttribute("href", "mailto:contact@laboranth.tech")
}

function header(parent) {

  function search(array, string) {
    let listing = []

    array.forEach(e => {
      if (e.match(string)) {
        listing.push(e)
      }
    })

    return Array.from(new Set(listing))
  }

  const header = lab_design_system_d("header", "header", parent, 0, 0, ["containers", "header"])

  const logo = lab_design_system_d("a", "logo", header, 0, 0, null);
  logo.setAttribute("href", "/")


  const logoImg = lab_design_system_d("img", "logo-img", logo, null, null, ["logo", "small"]);
  logoImg.setAttribute("src", "https://laboranth.tech/D/R/IMG/logoAlt.svg")


  const searchBox = lab_design_system_d("div", "search-box", header, null, null, ["search", "box"])

  const searchImage = lab_design_system_d("img", "search-img", searchBox, null, null, null)
  searchImage.setAttribute("src", "/content/sections/profile/img/search.svg")

  const searchInput = lab_design_system_d("input", "search", searchBox, null, "search", ["search", "input"])

  const result = lab_design_system_d("div", "result", searchBox, null, null, ["search", "result"])

  searchInput.addEventListener("input", () => {
    result.innerHTML = ""
    if (searchInput.value.length) {
      myList = search(viewMyList ? appList : externalApps, searchInput.value)
      if (myList.length) {
        myList.forEach((item, index) => {
          const resultItem = lab_design_system_d("a", `result-${item}`, result, item, null, ['search', !index ? "first" : "item"])
          resultItem.setAttribute("href", `./${item}/home`)
        })
      }
    }

  })
  const gridSwitch = lab_design_system_d("div", "grid-switch", header, null, null, ["elements", "gridSwitch"])

  let activeSwitch = 'row'

  const gridLayouts = ['row', 'column']
  gridLayouts.forEach((e, index) => {
    const btn = lab_design_system_d("button", `grid-switch-${e}`, gridSwitch, null, null, ["elements", "gridBtn"])

    e == activeSwitch && (btn.style.background = "#fff")


    const icon = lab_design_system_d("img", `grid-icon-${e}`, btn)
    icon.setAttribute('src', `/content/sections/profile/img/${e}.svg`)
    icon.style.maxWidth = '100%'

    btn.addEventListener('click', () => {
      if (e != activeSwitch) {
        document.getElementById(`lab-grid-switch-${e == 'row' ? "column" : "row"}`).style.background = "transparent"
        btn.style.background = "#fff"

        activeSwitch = e

        viewMyList ? renderList(appList, e) : renderList(externalApps, e)
      }

    })
  })

  const create = lab_design_system_d("button", "create-btn", header, "u.lngData.create", null, ["buttons", "action"])

  create.addEventListener("click", e => {
    lab_fade_in_recursively(wrapper, 0.3)

    const createPopup = popup('delete-app', rootLayer)
    const popupTitle = lab_design_system_d("span", "popup-title", createPopup, "u.lngData.create_app", null, ['popup', 'title'])

    const popupInput = input('name', 'create', createPopup, null, '100%', ['popup', 'input'])
    const createPopupBtn = lab_design_system_d("button", "create-popup-btn", createPopup, "u.lngData.create", null, ["buttons", "action"])

    lab_fade_in_recursively(createPopup, 0.3)

    const lab_user_current_config = lab_local_storage_object('global')

    createPopupBtn.addEventListener('click', () => {
      lab_user_current_config.newApp = popupInput.value
      socket.emit("createApp", lab_user_current_config)
      window.reload()
    })

  })

  const avatar = lab_design_system_d("button", "user-avatar", header, null, null, ['elements', 'avatar'])

  avatar.addEventListener("click", () => {

    if (document.getElementById("lab-header-menu")) {
      const menu = document.getElementById("lab-header-menu")
      avatar.removeChild(menu)
    } else {
      const headerMenu = lab_design_system_d("div", "header-menu", avatar, null, null, ['header', 'menu'])

      headerMenu.addEventListener('mouseleave', () => {
        avatar.removeChild(headerMenu)
      })

      const menuList = ['settings', 'plans', 'logout']

      menuList.forEach(e => {
        const item = lab_design_system_d("a", `menu-${e}`, headerMenu, e, null, ['header', 'link'])
        const image = lab_design_system_d("img", `${e}-img`, item, null, null, null)
        image.setAttribute("src", `/content/sections/profile/img/${e}.svg`)
        item.addEventListener('click', () => {
          if (e == 'logout') {
            localStorage.clear()
            window.open("https://laboranth.tech/", "_self")
          }
          else if (e == 'settings') {
            socket.emit('askAccount', lab_local_storage_object('global'), res => {
              lab_load_language_module(res.configs.language).then(lngData => {
                res.lngData = lngData
                res.lng = res.configs.language
                dash_parameters(res)
              })
            })

          }
        })
      })

      lab_fade_in_recursively(headerMenu, 0.6)

    }
  })

}

function input(placeholder, value, parent, func, width, style) {
  const input = lab_design_system_d("input", `input-${value}`, parent, null, null, (style || ["input", 'box']))
  input.placeholder = placeholder
  width ? input.style.width = `${width}` : ""

  input.addEventListener("input", () => func(input.value))
  return input
}



function plans() {

  const tariff = [
    {
      title: "Free",
      description: "Tariff where you can get acquainted with the service's capabilities and create your own website",
      price: {
        mounth: 0,
        year: 0
      },
      points: [
        'Creation of 3 projects',
        'Disk space 200MB',
        'Content and Plugins Basic'
      ],
      color: {
        label: "black",
        value: "#243042"
      }
    },
    {
      title: "Personal",
      description: "Suitable for aspiring businessmen, individual entrepreneurs and experts",
      price: {
        mounth: 35,
        year: 420
      },
      points: [
        'Creation of 15 projects',
        'Disk space 1GB',
        'Export git / .zip / serveurs persos (purchasing servers from our partners)',
        'Linking your domain',
        'Content and Plugins Basic',
        'Content and Plugins Pro'
      ],
      color: {
        label: "green",
        value: "#3e8483"
      }
    },
    {
      title: "Business Lite",
      description: "An exceptional choice for growing businesses with up to 5 team members.",
      price: {
        mounth: 60,
        year: 720
      },
      points: [
        'Unlimited project creation',
        'Disk space 10GB',
        '5 collaborators',
        'Export git / .zip / serveurs persos /serveurs auto',
        'Linking your domain',
        'Content and Plugins Basic',
        'Content and Plugins Pro'
      ],
      subPoints: [
        'Full transfer of source code',
        'Using AI',
        'Ephemeral sharing',
        'Payment tools',
        'Automaticly daily backup'
      ],
      color: {
        label: "orange",
        value: "#ff642a"
      }
    },
    {
      title: "Business Premium",
      description: "For businesses that want to use all the capabilities of the service. Also ideal for web studios and IT companies",
      price: {
        mounth: 350,
        year: 4200
      },
      points: [
        'Unlimited project creation',
        'Disk space 50GB',
        '15 collaborators',
        'Export git / .zip / serveurs persos /serveurs auto',
        'Linking your domain',
        'Content and Plugins Basic',
        'Content and Plugins Pro',
        'Content and Plugins VIP'
      ],
      subPoints: [
        'Full transfer of source code',
        'Using AI',
        'Ephemeral sharing',
        'Payment tools',
        'Automaticly daily backup',
        'eCommerce',
        'Access to training materials'
      ],
      color: {
        label: "blue",
        value: "#2463eb"
      }
    },
    {
      title: "Tailored",
      description: "Extended solution for high scale businesses and organizations like universities",
      heading: "On request",
      color: {
        label: "yellow",
        value: "#fed05e"
      }
    }
  ]

  rootLayer.style.overflowY = "auto"
  const wrapper = lab_design_system_d("div", "body-wrapper", rootLayer, 0, 0, ["pages", "dash"])
  header(wrapper)

  const wrap = lab_design_system_d("div", "plans", wrapper, 0, 0, ["plans", "wrap"])

  tariff.forEach((e, index) => {
    const item = lab_design_system_d("div", `plans-${index}`, wrap, 0, 0, ["plans", "plan"])
    const angle = lab_design_system_d("img", `plans-angle-${index}`, item, 0, 0, ["plans", "angle"])
    angle.setAttribute('src', `/content/sections/profile/img/point-card-${e.color.label}.svg`)
    const title = lab_design_system_d("span", `plans-title-${index}`, item, e.title, 0, ["plans", "title"])
    const description = lab_design_system_d("p", `plans-description-${index}`, item, e.description, 0, ["plans", "description"])
    if (e.price) {

      const priceBox = lab_design_system_d("div", `plans-box-${index}`, item, 0, 0, ["plans", "box"])
      const currency = lab_design_system_d("div", `plans-currency-${index}`, priceBox, 'usd ', 0, 0)
      const price = lab_design_system_d("div", `plans-price-${index}`, priceBox, String(e.price.mounth), 0, ["plans", "price"])
      const duration = lab_design_system_d("div", `plans-duration-${index}`, priceBox, ' /month', 0, 0)
    }
    function renderPoint(list, type = '') {
      const points = lab_design_system_d("div", `points-${type}-${index}`, item, 0, 0, ['plans', 'points'])
      list.forEach((p, i) => {
        const point = lab_design_system_d("div", `point-${type}-${index}-${i}`, points, 0, 0, ['plans', 'point'])
        const img = lab_design_system_d("img", `point-img-${type}-${index}-${i}`, point)
        img.setAttribute('src', `/content/sections/profile/img/point-${e.color.label}.svg`)
        const span = lab_design_system_d("span", `point-text-${type}-${index}-${i}`, point, p, 0, (type ? ['plans', type] : 0))
      })
    }

    e.points && renderPoint(e.points)
    e.subPoints && renderPoint(e.points, 'bold')

    e.heading && lab_design_system_d("span", `heading-${index}`, item, e.heading, 0, ['plans', 'heading'])

    const btn = lab_design_system_d("button", `plan-btn-${index}`, item, 'Choose plan', 0, ['plans', 'btn'])
    btn.style.backgroundColor = e.color.value
    e.color.label == 'yellow' && (btn.style.color = '#000')
  })

  footer(wrapper)
  lab_fade_in_recursively(wrapper, 0.3)
}

plans()



